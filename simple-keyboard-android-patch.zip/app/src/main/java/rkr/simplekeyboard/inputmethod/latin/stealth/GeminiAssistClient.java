package rkr.simplekeyboard.inputmethod.latin.stealth;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rkr.simplekeyboard.inputmethod.BuildConfig;

public final class GeminiAssistClient {
    public interface Callback {
        void onSuccess(String resultText);
        void onError(String errorMessage);
    }

    public static final class ChatTurn {
        public final String role; // "user" or "model"
        public final String text;

        public ChatTurn(final String role, final String text) {
            this.role = role;
            this.text = text;
        }
    }

    private static final String ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-4-hydrogen:generateContent";
    private static final int MAX_HISTORY_TURNS = 16;

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final List<ChatTurn> CONVERSATION_HISTORY = new ArrayList<>();

    private GeminiAssistClient() {}

    public static synchronized void clearHistory() {
        CONVERSATION_HISTORY.clear();
    }

    public static void runAction(final String action, final String inputText, final Callback callback) {
        final String apiKey = BuildConfig.GEMINI_API_KEY;
        if (TextUtils.isEmpty(apiKey)) {
            MAIN_HANDLER.post(() -> callback.onError(
                    "GEMINI_API_KEY belum diisi di GitHub Secrets saat build APK."));
            return;
        }
        if (TextUtils.isEmpty(inputText) || inputText.trim().isEmpty()) {
            MAIN_HANDLER.post(() -> callback.onError(
                    "Ketik pertanyaan, gunakan 'Ketik Soal', atau salin teks soal terlebih dahulu."));
            return;
        }

        final String trimmedInput = inputText.trim();
        final String systemPrompt = getInstructionForAction(action);

        final List<ChatTurn> snapshot;
        synchronized (GeminiAssistClient.class) {
            snapshot = new ArrayList<>(CONVERSATION_HISTORY);
        }

        EXECUTOR.execute(() -> {
            HttpURLConnection conn = null;
            try {
                final URL url = new URL(ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(35000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setRequestProperty("x-goog-api-key", apiKey);

                final JSONArray contentsArray = new JSONArray();
                final int startIdx = Math.max(0, snapshot.size() - (MAX_HISTORY_TURNS - 2));
                for (int i = startIdx; i < snapshot.size(); i++) {
                    final ChatTurn turn = snapshot.get(i);
                    contentsArray.put(new JSONObject()
                            .put("role", turn.role)
                            .put("parts", new JSONArray().put(
                                    new JSONObject().put("text", turn.text))));
                }
                contentsArray.put(new JSONObject()
                        .put("role", "user")
                        .put("parts", new JSONArray().put(
                                new JSONObject().put("text", trimmedInput))));

                final JSONObject sysPart = new JSONObject().put("text", systemPrompt);
                final JSONObject sysInstr = new JSONObject()
                        .put("parts", new JSONArray().put(sysPart));

                final JSONObject payload = new JSONObject()
                        .put("system_instruction", sysInstr)
                        .put("contents", contentsArray);

                final byte[] outBytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(outBytes);
                }

                final int status = conn.getResponseCode();
                final InputStream stream = status >= 200 && status < 300
                        ? conn.getInputStream()
                        : conn.getErrorStream();
                final String responseStr = readStream(stream);

                if (status < 200 || status >= 300) {
                    final String friendlyErr = extractApiError(status, responseStr);
                    MAIN_HANDLER.post(() -> callback.onError(friendlyErr));
                    return;
                }

                final JSONObject json = new JSONObject(responseStr);
                final JSONArray candidates = json.optJSONArray("candidates");
                if (candidates == null || candidates.length() == 0) {
                    MAIN_HANDLER.post(() -> callback.onError("Tidak ada respons dari Gemini."));
                    return;
                }
                final JSONObject firstCandidate = candidates.getJSONObject(0);
                final JSONObject respContent = firstCandidate.optJSONObject("content");
                final JSONArray parts = respContent != null ? respContent.optJSONArray("parts") : null;
                if (parts == null || parts.length() == 0) {
                    MAIN_HANDLER.post(() -> callback.onError("Respons AI kosong."));
                    return;
                }
                final String result = parts.getJSONObject(0).optString("text", "").trim();
                if (result.isEmpty()) {
                    MAIN_HANDLER.post(() -> callback.onError("Respons AI kosong."));
                } else {
                    synchronized (GeminiAssistClient.class) {
                        CONVERSATION_HISTORY.add(new ChatTurn("user", trimmedInput));
                        CONVERSATION_HISTORY.add(new ChatTurn("model", result));
                        while (CONVERSATION_HISTORY.size() > MAX_HISTORY_TURNS) {
                            CONVERSATION_HISTORY.remove(0);
                        }
                    }
                    MAIN_HANDLER.post(() -> callback.onSuccess(result));
                }
            } catch (final Exception e) {
                final String msg = e.getMessage() != null ? e.getMessage() : "Gagal menghubungi Gemini AI.";
                MAIN_HANDLER.post(() -> callback.onError(msg));
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        });
    }

    private static String extractApiError(final int status, final String raw) {
        try {
            final JSONObject root = new JSONObject(raw);
            final JSONObject err = root.optJSONObject("error");
            if (err != null) {
                final String msg = err.optString("message", "");
                if (!msg.isEmpty()) return "Error " + status + ": " + msg;
            }
        } catch (final Exception ignored) {
        }
        return "Error HTTP " + status;
    }

    private static String getInstructionForAction(final String action) {
        switch (action) {
            case "tutor":
                return "Kamu adalah Tutor Belajar AI yang sabar, jelas, dan akurat untuk semua mata pelajaran (Matematika, IPA/Fisika/Kimia/Biologi, Bahasa, Sejarah, Geografi, Ekonomi, PPKn, Informatika/Koding). Jawab dalam bahasa yang sama dengan pertanyaan pengguna. Untuk soal hitungan/sains, jelaskan konsep singkat, langkah penyelesaian bertahap dengan notasi teks rapi (seperti x², √, /), dan jawaban akhir yang jelas. Untuk materi pelajaran, jelaskan terstruktur dan mudah dipahami.";
            case "solve":
                return "Kamu adalah tutor pemecah soal pelajaran. Selesaikan soal secara bertahap: diketahui, rumus/konsep, langkah perhitungan rapi dalam teks biasa, dan jawaban akhir yang jelas. Gunakan bahasa yang sama dengan input.";
            case "explain":
                return "Jelaskan materi atau topik pelajaran ini dengan bahasa sederhana dan mudah dipahami: pengertian inti, contoh nyata/analogi, dan poin penting yang perlu diingat.";
            case "quiz":
                return "Buatkan 2 soal latihan terkait materi atau teks ini beserta pembahasan langkah demi langkah dan kunci jawabannya.";
            case "check":
                return "Periksa jawaban atau pekerjaan siswa pada input. Jelaskan apakah sudah benar atau bagian mana yang keliru secara ramah, lalu tunjukkan langkah penyelesaian yang tepat.";
            case "ask":
                return "Jawab pertanyaan pengguna secara jelas, akurat, dan ringkas dalam bahasa yang sama. Berikan langsung jawabannya.";
            case "reply":
                return "Buatkan draf balasan chat yang natural, sopan, dan membantu dalam bahasa yang sama. Berikan hanya teks balasannya saja.";
            case "fix":
                return "Perbaiki ejaan, tata bahasa, dan tanda baca dengan rapi sambil mempertahankan bahasa dan makna aslinya. Berikan hanya teks hasil perbaikan.";
            case "polish":
                return "Tulis ulang teks agar terdengar jelas, rapi, dan profesional dalam bahasa yang sama. Berikan hanya teks hasilnya.";
            case "casual":
                return "Tulis ulang teks dengan gaya santai, hangat, dan ramah dalam bahasa yang sama. Berikan hanya teks hasilnya.";
            case "translate":
                return "Jika teks utama berbahasa Indonesia, terjemahkan ke bahasa Inggris secara natural. Jika bukan, terjemahkan ke bahasa Indonesia secara natural. Berikan hanya terjemahannya.";
            case "summarize":
                return "Ringkas materi atau teks ini menjadi poin-poin inti yang padat dan mudah dipelajari dalam bahasa yang sama.";
            case "continue":
                return "Lanjutkan teks secara natural dengan 1-3 kalimat yang relevan dalam bahasa dan nada yang sama. Berikan hanya lanjutannya.";
            default:
                return "Bantu pengguna memahami atau menyempurnakan teks/pertanyaan berikut secara jelas dalam bahasa yang sama.";
        }
    }

    private static String readStream(final InputStream is) throws Exception {
        if (is == null) return "";
        final StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }
}

package rkr.simplekeyboard.inputmethod.latin.stealth;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import rkr.simplekeyboard.inputmethod.compat.PreferenceManagerCompat;

public final class ClipboardHistoryManager {
    private static final String PREF_KEY = "stealth_clipboard_history_v1";
    private static final int MAX_ITEMS = 25;

    public static final class ClipEntry {
        public final String text;
        public boolean pinned;
        public final long createdAt;

        public ClipEntry(final String text, final boolean pinned, final long createdAt) {
            this.text = text;
            this.pinned = pinned;
            this.createdAt = createdAt;
        }
    }

    private final SharedPreferences mPrefs;
    private final ClipboardManager mClipboardManager;
    private final List<ClipEntry> mEntries = new ArrayList<>();
    private Runnable mOnChangeListener;

    private final ClipboardManager.OnPrimaryClipChangedListener mSystemClipListener =
            new ClipboardManager.OnPrimaryClipChangedListener() {
                @Override
                public void onPrimaryClipChanged() {
                    final String latest = readSystemClipboard();
                    if (!TextUtils.isEmpty(latest)) {
                        addClip(latest);
                    }
                }
            };

    public ClipboardHistoryManager(final Context context) {
        mPrefs = PreferenceManagerCompat.getDeviceSharedPreferences(context);
        mClipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        loadFromPrefs();
    }

    public void startListening() {
        if (mClipboardManager != null) {
            try {
                mClipboardManager.addPrimaryClipChangedListener(mSystemClipListener);
            } catch (final Exception ignored) {
            }
        }
    }

    public void stopListening() {
        if (mClipboardManager != null) {
            try {
                mClipboardManager.removePrimaryClipChangedListener(mSystemClipListener);
            } catch (final Exception ignored) {
            }
        }
    }

    public void setOnChangeListener(final Runnable listener) {
        mOnChangeListener = listener;
    }

    public String readSystemClipboard() {
        if (mClipboardManager == null || !mClipboardManager.hasPrimaryClip()) {
            return null;
        }
        try {
            final ClipData clip = mClipboardManager.getPrimaryClip();
            if (clip != null && clip.getItemCount() > 0) {
                final CharSequence cs = clip.getItemAt(0).getText();
                return cs != null ? cs.toString() : null;
            }
        } catch (final Exception ignored) {
        }
        return null;
    }

    public void writeSystemClipboard(final String text) {
        if (mClipboardManager == null || TextUtils.isEmpty(text)) {
            return;
        }
        try {
            mClipboardManager.setPrimaryClip(ClipData.newPlainText("text", text));
        } catch (final Exception ignored) {
        }
    }

    public synchronized List<ClipEntry> getClips() {
        return new ArrayList<>(mEntries);
    }

    public synchronized void addClip(final String text) {
        if (text == null || text.trim().isEmpty()) {
            return;
        }
        boolean wasPinned = false;
        for (int i = mEntries.size() - 1; i >= 0; i--) {
            if (text.equals(mEntries.get(i).text)) {
                wasPinned = mEntries.get(i).pinned;
                mEntries.remove(i);
            }
        }
        mEntries.add(0, new ClipEntry(text, wasPinned, System.currentTimeMillis()));
        reorderPinnedFirst();
        if (mEntries.size() > MAX_ITEMS) {
            while (mEntries.size() > MAX_ITEMS) {
                mEntries.remove(mEntries.size() - 1);
            }
        }
        saveToPrefs();
        notifyChanged();
    }

    public synchronized void togglePin(final int index) {
        if (index < 0 || index >= mEntries.size()) return;
        mEntries.get(index).pinned = !mEntries.get(index).pinned;
        reorderPinnedFirst();
        saveToPrefs();
        notifyChanged();
    }

    public synchronized void deleteAt(final int index) {
        if (index < 0 || index >= mEntries.size()) return;
        mEntries.remove(index);
        saveToPrefs();
        notifyChanged();
    }

    public synchronized void clearUnpinned() {
        for (int i = mEntries.size() - 1; i >= 0; i--) {
            if (!mEntries.get(i).pinned) {
                mEntries.remove(i);
            }
        }
        saveToPrefs();
        notifyChanged();
    }

    private void reorderPinnedFirst() {
        final List<ClipEntry> pinned = new ArrayList<>();
        final List<ClipEntry> normal = new ArrayList<>();
        for (final ClipEntry entry : mEntries) {
            if (entry.pinned) pinned.add(entry);
            else normal.add(entry);
        }
        mEntries.clear();
        mEntries.addAll(pinned);
        mEntries.addAll(normal);
    }

    private void loadFromPrefs() {
        mEntries.clear();
        final String raw = mPrefs.getString(PREF_KEY, null);
        if (TextUtils.isEmpty(raw)) return;
        try {
            final JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                final JSONObject obj = arr.getJSONObject(i);
                final String text = obj.optString("text", "");
                if (!text.isEmpty()) {
                    mEntries.add(new ClipEntry(
                            text,
                            obj.optBoolean("pinned", false),
                            obj.optLong("createdAt", 0L)));
                }
            }
        } catch (final JSONException ignored) {
        }
    }

    private void saveToPrefs() {
        final JSONArray arr = new JSONArray();
        for (final ClipEntry entry : mEntries) {
            try {
                final JSONObject obj = new JSONObject();
                obj.put("text", entry.text);
                obj.put("pinned", entry.pinned);
                obj.put("createdAt", entry.createdAt);
                arr.put(obj);
            } catch (final JSONException ignored) {
            }
        }
        mPrefs.edit().putString(PREF_KEY, arr.toString()).apply();
    }

    private void notifyChanged() {
        if (mOnChangeListener != null) {
            mOnChangeListener.run();
        }
    }
}

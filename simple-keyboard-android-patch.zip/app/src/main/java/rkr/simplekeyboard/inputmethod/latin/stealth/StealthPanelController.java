package rkr.simplekeyboard.inputmethod.latin.stealth;

import android.content.res.ColorStateList;
import android.inputmethodservice.InputMethodService;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

import rkr.simplekeyboard.inputmethod.R;
import rkr.simplekeyboard.inputmethod.latin.common.Constants;

public final class StealthPanelController {
    private final InputMethodService mIme;
    private final ClipboardHistoryManager mClipboardManager;

    private View mPanelRoot;
    private View mTabClipboard;
    private View mTabAi;
    private Button mBtnTabClipboard;
    private Button mBtnTabAi;
    private LinearLayout mClipListContainer;
    private TextView mEmptyClipsView;

    private Button mBtnAiTypeToggle;
    private TextView mAiDraftView;
    private Button mBtnAiClearDraft;
    private TextView mAiStatusView;
    private ScrollView mAiResultScroll;
    private TextView mAiResultView;
    private View mAiActionBar;

    private boolean mIsVisible = false;
    private boolean mShowingAiTab = false;
    private boolean mAiTypingActive = false;

    private final StringBuilder mAiDraftBuilder = new StringBuilder();
    private final StringBuilder mTranscriptBuilder = new StringBuilder();

    private String mLastAiAction = "tutor";
    private String mLastAiSource = "";
    private String mLastAiResult = "";
    private boolean mLastUsedSelection = false;
    private int mLastBeforeLength = 0;

    public StealthPanelController(final InputMethodService ime) {
        mIme = ime;
        mClipboardManager = new ClipboardHistoryManager(ime);
        mClipboardManager.setOnChangeListener(() -> {
            if (mPanelRoot != null) {
                mPanelRoot.post(this::renderClipboardList);
            }
        });
    }

    public void onCreate() {
        mClipboardManager.startListening();
    }

    public void onDestroy() {
        mClipboardManager.stopListening();
    }

    public void attachToInputView(final View inputView) {
        if (inputView == null) return;
        mPanelRoot = inputView.findViewById(R.id.stealth_panel);
        if (mPanelRoot == null) return;

        mTabClipboard = mPanelRoot.findViewById(R.id.stealth_tab_clipboard);
        mTabAi = mPanelRoot.findViewById(R.id.stealth_tab_ai);
        mBtnTabClipboard = mPanelRoot.findViewById(R.id.btn_tab_clipboard);
        mBtnTabAi = mPanelRoot.findViewById(R.id.btn_tab_ai);
        mClipListContainer = mPanelRoot.findViewById(R.id.clip_list_container);
        mEmptyClipsView = mPanelRoot.findViewById(R.id.empty_clips_text);

        mBtnAiTypeToggle = mPanelRoot.findViewById(R.id.btn_ai_type_toggle);
        mAiDraftView = mPanelRoot.findViewById(R.id.ai_draft_text);
        mBtnAiClearDraft = mPanelRoot.findViewById(R.id.btn_ai_clear_draft);
        mAiStatusView = mPanelRoot.findViewById(R.id.ai_status_text);
        mAiResultScroll = mPanelRoot.findViewById(R.id.ai_result_scroll);
        mAiResultView = mPanelRoot.findViewById(R.id.ai_result_text);
        mAiActionBar = mPanelRoot.findViewById(R.id.ai_result_actions);

        mPanelRoot.setVisibility(mIsVisible ? View.VISIBLE : View.GONE);

        mBtnTabClipboard.setOnClickListener(v -> switchTab(false));
        mBtnTabAi.setOnClickListener(v -> switchTab(true));
        mPanelRoot.findViewById(R.id.btn_stealth_hide).setOnClickListener(v -> hide());

        mPanelRoot.findViewById(R.id.btn_action_copy).setOnClickListener(v -> performCopy(false));
        mPanelRoot.findViewById(R.id.btn_action_copy_all).setOnClickListener(v -> performCopy(true));
        mPanelRoot.findViewById(R.id.btn_action_cut).setOnClickListener(v -> performCut());
        mPanelRoot.findViewById(R.id.btn_action_paste).setOnClickListener(v -> performPaste(false));
        mPanelRoot.findViewById(R.id.btn_action_paste_enter).setOnClickListener(v -> performPaste(true));
        mPanelRoot.findViewById(R.id.btn_action_clear_clips).setOnClickListener(v -> {
            mClipboardManager.clearUnpinned();
            renderClipboardList();
        });

        // Study Tutor & AI Actions
        mPanelRoot.findViewById(R.id.btn_ai_tutor).setOnClickListener(v -> triggerAi("tutor"));
        mPanelRoot.findViewById(R.id.btn_ai_solve).setOnClickListener(v -> triggerAi("solve"));
        mPanelRoot.findViewById(R.id.btn_ai_explain).setOnClickListener(v -> triggerAi("explain"));
        mPanelRoot.findViewById(R.id.btn_ai_quiz).setOnClickListener(v -> triggerAi("quiz"));
        mPanelRoot.findViewById(R.id.btn_ai_check).setOnClickListener(v -> triggerAi("check"));
        mPanelRoot.findViewById(R.id.btn_ai_summarize).setOnClickListener(v -> triggerAi("summarize"));
        mPanelRoot.findViewById(R.id.btn_ai_reply).setOnClickListener(v -> triggerAi("reply"));
        mPanelRoot.findViewById(R.id.btn_ai_fix).setOnClickListener(v -> triggerAi("fix"));
        mPanelRoot.findViewById(R.id.btn_ai_polish).setOnClickListener(v -> triggerAi("polish"));
        mPanelRoot.findViewById(R.id.btn_ai_casual).setOnClickListener(v -> triggerAi("casual"));
        mPanelRoot.findViewById(R.id.btn_ai_translate).setOnClickListener(v -> triggerAi("translate"));
        mPanelRoot.findViewById(R.id.btn_ai_continue).setOnClickListener(v -> triggerAi("continue"));

        // Private AI Question Draft Bar
        mBtnAiTypeToggle.setOnClickListener(v -> setAiTypingActive(!mAiTypingActive));
        mAiDraftView.setOnClickListener(v -> setAiTypingActive(true));
        mPanelRoot.findViewById(R.id.btn_ai_paste_question).setOnClickListener(v -> pasteClipboardToDraft());
        mBtnAiClearDraft.setOnClickListener(v -> {
            mAiDraftBuilder.setLength(0);
            updateDraftUi();
        });
        mPanelRoot.findViewById(R.id.btn_ai_send_draft).setOnClickListener(v -> triggerAi("tutor"));

        // Result Actions
        mPanelRoot.findViewById(R.id.btn_ai_replace).setOnClickListener(v -> applyAiResult(true));
        mPanelRoot.findViewById(R.id.btn_ai_insert).setOnClickListener(v -> applyAiResult(false));
        mPanelRoot.findViewById(R.id.btn_ai_copy_result).setOnClickListener(v -> {
            if (!TextUtils.isEmpty(mLastAiResult)) {
                mClipboardManager.writeSystemClipboard(mLastAiResult);
                mClipboardManager.addClip(mLastAiResult);
                showAiStatus("Jawaban terakhir disalin.");
            }
        });
        mPanelRoot.findViewById(R.id.btn_ai_save_clip).setOnClickListener(v -> {
            if (!TextUtils.isEmpty(mLastAiResult)) {
                mClipboardManager.addClip(mLastAiResult);
                mClipboardManager.writeSystemClipboard(mLastAiResult);
                showAiStatus("Disimpan ke papan klip.");
            }
        });
        mPanelRoot.findViewById(R.id.btn_ai_retry).setOnClickListener(v -> {
            if (!TextUtils.isEmpty(mLastAiSource)) {
                runAiWithSource(mLastAiAction, mLastAiSource);
            }
        });
        mPanelRoot.findViewById(R.id.btn_ai_new_chat).setOnClickListener(v -> resetConversation());

        switchTab(mShowingAiTab);
        updateDraftUi();
        refreshAiChatUi();
        renderClipboardList();
    }

    public boolean isAiTypingActive() {
        return mIsVisible && mShowingAiTab && mAiTypingActive;
    }

    public boolean handleInterceptedCodeInput(final int codePoint) {
        if (!isAiTypingActive()) {
            return false;
        }
        if (codePoint == Constants.CODE_SHIFT
                || codePoint == Constants.CODE_CAPSLOCK
                || codePoint == Constants.CODE_SWITCH_ALPHA_SYMBOL
                || codePoint == Constants.CODE_SYMBOL_SHIFT
                || codePoint == Constants.CODE_SETTINGS
                || codePoint == Constants.CODE_LANGUAGE_SWITCH
                || codePoint == Constants.CODE_ACTION_NEXT
                || codePoint == Constants.CODE_ACTION_PREVIOUS) {
            return false;
        }
        if (codePoint == Constants.CODE_DELETE) {
            final int len = mAiDraftBuilder.length();
            if (len > 0) {
                final int prevCodePoint = Character.codePointBefore(mAiDraftBuilder, len);
                mAiDraftBuilder.delete(len - Character.charCount(prevCodePoint), len);
                updateDraftUi();
            }
            return true;
        }
        if (codePoint == Constants.CODE_ENTER) {
            triggerAi("tutor");
            return true;
        }
        if (codePoint == Constants.CODE_SHIFT_ENTER) {
            mAiDraftBuilder.append('\n');
            updateDraftUi();
            return true;
        }
        if (codePoint == Constants.CODE_PASTE) {
            pasteClipboardToDraft();
            return true;
        }
        if (codePoint >= Constants.CODE_SPACE || codePoint == Constants.CODE_TAB) {
            mAiDraftBuilder.append(Character.toChars(codePoint));
            updateDraftUi();
            return true;
        }
        return true;
    }

    public boolean handleInterceptedTextInput(final String rawText) {
        if (!isAiTypingActive()) {
            return false;
        }
        if (!TextUtils.isEmpty(rawText)) {
            mAiDraftBuilder.append(rawText);
            updateDraftUi();
        }
        return true;
    }

    public boolean toggle() {
        mIsVisible = !mIsVisible;
        if (!mIsVisible) {
            setAiTypingActive(false);
        }
        if (mPanelRoot != null) {
            mPanelRoot.setVisibility(mIsVisible ? View.VISIBLE : View.GONE);
            if (mIsVisible) {
                final String sysClip = mClipboardManager.readSystemClipboard();
                if (!TextUtils.isEmpty(sysClip)) {
                    mClipboardManager.addClip(sysClip);
                }
                renderClipboardList();
            }
        }
        return true;
    }

    public void hide() {
        mIsVisible = false;
        setAiTypingActive(false);
        if (mPanelRoot != null) {
            mPanelRoot.setVisibility(View.GONE);
        }
    }

    private void setAiTypingActive(final boolean active) {
        mAiTypingActive = active;
        if (mBtnAiTypeToggle != null) {
            mBtnAiTypeToggle.setText(active ? "Ketik: ON" : "Ketik Soal");
            mBtnAiTypeToggle.setBackgroundTintList(ColorStateList.valueOf(
                    active ? 0xFF0284C7 : 0xFF37474F));
        }
    }

    private void pasteClipboardToDraft() {
        String text = mClipboardManager.readSystemClipboard();
        if (TextUtils.isEmpty(text)) {
            final List<ClipboardHistoryManager.ClipEntry> clips = mClipboardManager.getClips();
            if (!clips.isEmpty()) {
                text = clips.get(0).text;
            }
        }
        if (!TextUtils.isEmpty(text)) {
            if (mAiDraftBuilder.length() > 0 && mAiDraftBuilder.charAt(mAiDraftBuilder.length() - 1) != ' ') {
                mAiDraftBuilder.append(' ');
            }
            mAiDraftBuilder.append(text);
            updateDraftUi();
        } else {
            showAiStatus("Papan klip masih kosong.");
        }
    }

    private void updateDraftUi() {
        if (mAiDraftView != null) {
            mAiDraftView.setText(mAiDraftBuilder.toString());
        }
        if (mBtnAiClearDraft != null) {
            mBtnAiClearDraft.setVisibility(mAiDraftBuilder.length() > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void switchTab(final boolean aiTab) {
        mShowingAiTab = aiTab;
        if (!aiTab) {
            setAiTypingActive(false);
        }
        if (mTabClipboard != null && mTabAi != null) {
            mTabClipboard.setVisibility(aiTab ? View.GONE : View.VISIBLE);
            mTabAi.setVisibility(aiTab ? View.VISIBLE : View.GONE);
        }
        if (mBtnTabClipboard != null && mBtnTabAi != null) {
            mBtnTabClipboard.setAlpha(aiTab ? 0.55f : 1.0f);
            mBtnTabAi.setAlpha(aiTab ? 1.0f : 0.55f);
        }
    }

    private void performCopy(final boolean copyAll) {
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null) return;
        if (copyAll) {
            ic.performContextMenuAction(android.R.id.selectAll);
        }
        final CharSequence selected = ic.getSelectedText(0);
        if (!TextUtils.isEmpty(selected)) {
            final String text = selected.toString();
            mClipboardManager.writeSystemClipboard(text);
            mClipboardManager.addClip(text);
        } else if (copyAll) {
            final ExtractedText extracted = ic.getExtractedText(new ExtractedTextRequest(), 0);
            if (extracted != null && !TextUtils.isEmpty(extracted.text)) {
                final String full = extracted.text.toString();
                mClipboardManager.writeSystemClipboard(full);
                mClipboardManager.addClip(full);
            }
        } else {
            ic.performContextMenuAction(android.R.id.copy);
            final String sys = mClipboardManager.readSystemClipboard();
            if (!TextUtils.isEmpty(sys)) {
                mClipboardManager.addClip(sys);
            }
        }
    }

    private void performCut() {
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null) return;
        final CharSequence selected = ic.getSelectedText(0);
        if (!TextUtils.isEmpty(selected)) {
            final String text = selected.toString();
            mClipboardManager.writeSystemClipboard(text);
            mClipboardManager.addClip(text);
            ic.commitText("", 1);
        } else {
            ic.performContextMenuAction(android.R.id.cut);
        }
    }

    private void performPaste(final boolean appendNewline) {
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null) return;
        String pasteText = mClipboardManager.readSystemClipboard();
        if (TextUtils.isEmpty(pasteText)) {
            final List<ClipboardHistoryManager.ClipEntry> clips = mClipboardManager.getClips();
            if (!clips.isEmpty()) {
                pasteText = clips.get(0).text;
            }
        }
        if (!TextUtils.isEmpty(pasteText)) {
            mClipboardManager.addClip(pasteText);
            ic.commitText(appendNewline ? pasteText + "\n" : pasteText, 1);
            return;
        }
        ic.performContextMenuAction(android.R.id.paste);
    }

    private void triggerAi(final String action) {
        final String draftText = mAiDraftBuilder.toString().trim();
        if (!TextUtils.isEmpty(draftText)) {
            mLastUsedSelection = false;
            mLastBeforeLength = 0;
            mAiDraftBuilder.setLength(0);
            updateDraftUi();
            runAiWithSource(action, draftText);
            return;
        }

        final InputConnection ic = mIme.getCurrentInputConnection();
        String sourceText = "";
        if (ic != null) {
            final CharSequence selected = ic.getSelectedText(0);
            if (!TextUtils.isEmpty(selected)) {
                sourceText = selected.toString();
                mLastUsedSelection = true;
                mLastBeforeLength = 0;
            } else {
                final CharSequence before = ic.getTextBeforeCursor(2000, 0);
                sourceText = before != null ? before.toString() : "";
                mLastUsedSelection = false;
                mLastBeforeLength = sourceText.length();
            }
        }

        if (TextUtils.isEmpty(sourceText.trim())) {
            final String sysClip = mClipboardManager.readSystemClipboard();
            if (!TextUtils.isEmpty(sysClip)) {
                sourceText = sysClip;
                mLastBeforeLength = 0;
            } else {
                final List<ClipboardHistoryManager.ClipEntry> clips = mClipboardManager.getClips();
                if (!clips.isEmpty()) {
                    sourceText = clips.get(0).text;
                    mLastBeforeLength = 0;
                }
            }
        }

        runAiWithSource(action, sourceText);
    }

    private void runAiWithSource(final String action, final String sourceText) {
        mLastAiAction = action;
        mLastAiSource = sourceText;
        showAiStatus("Gemini AI sedang berpikir...");

        GeminiAssistClient.runAction(action, sourceText, new GeminiAssistClient.Callback() {
            @Override
            public void onSuccess(final String resultText) {
                mLastAiResult = resultText;
                if (mTranscriptBuilder.length() > 0) {
                    mTranscriptBuilder.append("\n\n----------------\n\n");
                }
                mTranscriptBuilder
                        .append("Anda: ")
                        .append(sourceText.trim())
                        .append("\n\nGemini AI:\n")
                        .append(resultText);

                if (mAiStatusView != null) {
                    mAiStatusView.setVisibility(View.GONE);
                }
                refreshAiChatUi();
            }

            @Override
            public void onError(final String errorMessage) {
                showAiStatus(errorMessage);
            }
        });
    }

    private void refreshAiChatUi() {
        if (mAiResultScroll == null || mAiResultView == null || mAiActionBar == null) return;
        final boolean hasTranscript = mTranscriptBuilder.length() > 0;
        mAiResultScroll.setVisibility(hasTranscript ? View.VISIBLE : View.GONE);
        mAiActionBar.setVisibility(hasTranscript ? View.VISIBLE : View.GONE);
        if (hasTranscript) {
            mAiResultView.setText(mTranscriptBuilder.toString());
            mAiResultScroll.post(() -> mAiResultScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void resetConversation() {
        GeminiAssistClient.clearHistory();
        mTranscriptBuilder.setLength(0);
        mLastAiResult = "";
        mLastAiSource = "";
        if (mAiResultScroll != null) {
            mAiResultScroll.setVisibility(View.GONE);
        }
        if (mAiActionBar != null) {
            mAiActionBar.setVisibility(View.GONE);
        }
        showAiStatus("Chat baru dimulai. Ketik atau tempel pertanyaan pelajaran Anda.");
    }

    private void showAiStatus(final String message) {
        if (mAiStatusView != null) {
            mAiStatusView.setVisibility(View.VISIBLE);
            mAiStatusView.setText(message);
        }
    }

    private void applyAiResult(final boolean replace) {
        final InputConnection ic = mIme.getCurrentInputConnection();
        if (ic == null || TextUtils.isEmpty(mLastAiResult)) return;

        if (replace) {
            if (mLastUsedSelection) {
                ic.commitText(mLastAiResult, 1);
            } else if (mLastBeforeLength > 0) {
                ic.deleteSurroundingText(mLastBeforeLength, 0);
                ic.commitText(mLastAiResult, 1);
            } else {
                ic.commitText(mLastAiResult, 1);
            }
        } else {
            ic.commitText(mLastAiResult, 1);
        }
        showAiStatus("Jawaban dimasukkan ke kotak teks.");
    }

    private void renderClipboardList() {
        if (mClipListContainer == null || mEmptyClipsView == null) return;
        mClipListContainer.removeAllViews();

        final List<ClipboardHistoryManager.ClipEntry> clips = mClipboardManager.getClips();
        mEmptyClipsView.setVisibility(clips.isEmpty() ? View.VISIBLE : View.GONE);

        for (int i = 0; i < clips.size(); i++) {
            final int index = i;
            final ClipboardHistoryManager.ClipEntry entry = clips.get(i);

            final LinearLayout row = new LinearLayout(mIme);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(12, 10, 12, 10);

            final TextView textView = new TextView(mIme);
            textView.setText((entry.pinned ? "[PIN] " : "") + entry.text);
            textView.setMaxLines(2);
            textView.setEllipsize(TextUtils.TruncateAt.END);
            textView.setTextSize(13f);
            textView.setTextColor(0xFFECEFF1);
            final LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            textView.setLayoutParams(textLp);
            textView.setOnClickListener(v -> {
                final InputConnection ic = mIme.getCurrentInputConnection();
                if (ic != null) {
                    ic.commitText(entry.text, 1);
                }
            });

            final Button pinBtn = new Button(mIme, null, android.R.attr.borderlessButtonStyle);
            pinBtn.setText(entry.pinned ? "Unpin" : "Pin");
            pinBtn.setTextSize(11f);
            pinBtn.setTextColor(0xFF81D4FA);
            pinBtn.setMinWidth(0);
            pinBtn.setMinimumWidth(0);
            pinBtn.setOnClickListener(v -> mClipboardManager.togglePin(index));

            final Button delBtn = new Button(mIme, null, android.R.attr.borderlessButtonStyle);
            delBtn.setText("×");
            delBtn.setTextSize(15f);
            delBtn.setTextColor(0xFFEF9A9A);
            delBtn.setMinWidth(0);
            delBtn.setMinimumWidth(0);
            delBtn.setOnClickListener(v -> mClipboardManager.deleteAt(index));

            row.addView(textView);
            row.addView(pinBtn);
            row.addView(delBtn);
            mClipListContainer.addView(row);
        }
    }
}

# Cara Build APK Simple Keyboard (dengan Papan Klip & Bantuan AI Tersembunyi)

Paket ini berisi file modifikasi untuk repositori asli **`rkkr/simple-keyboard`** agar bisa dikompilasi menjadi file **`.apk`** Android dan dipasang sebagai **keyboard sistem di HP Anda**.

## Fitur Tambahan di Versi Android
- **Tampilan normal tetap 100% Simple Keyboard** (tidak ada ikon AI atau papan klip yang terlihat).
- **Pemicu Rahasia**: **Tahan tombol Spasi** sekitar 0,5–0,7 detik (tanpa menggesernya) untuk memunculkan/menyembunyikan panel rahasia.
- **Salin, Potong, Tempel & Papan Klip**: Otomatis merekam teks yang Anda salin dari aplikasi mana pun, mendukung Pin/Unpin, hapus, dan tempel langsung ke aplikasi yang sedang dibuka.
- **Bantuan AI (Gemini)**: Rapikan ejaan, buat profesional, terjemahkan (ID ↔ EN), ringkas, atau lanjutkan tulisan langsung dari dalam keyboard.

## Langkah Build `.apk` Gratis Lewat GitHub (Tanpa PC / Android Studio)
1. Buat akun GitHub (jika belum punya), lalu buka `https://github.com/rkkr/simple-keyboard` dan klik **Fork** ke akun GitHub Anda.
2. Di repositori hasil fork Anda, salin/timpa semua file dari folder zip ini (`app/`, `.github/workflows/build-apk.yml`) ke root repositori Anda (menimpa `app/build.gradle`, `AndroidManifest.xml`, `input_view.xml`, `Constants.java`, `PointerTracker.java`, `LatinIME.java`, dan menambahkan file baru).
3. *(Opsional untuk Bantuan AI)* Buka **Settings → Secrets and variables → Actions → New repository secret** di repositori GitHub Anda, lalu tambahkan:
   - Name: `GEMINI_API_KEY`
   - Secret: *(API key Gemini Anda dari Google AI Studio)*
4. Buka tab **Actions** di GitHub → pilih workflow **Build Simple Keyboard APK** → klik **Run workflow**.
5. Setelah selesai (±2–3 menit), unduh artefak **`simple-keyboard-debug-apk`** (`app-debug.apk`), pindahkan ke HP Android Anda, lalu instal.
6. Buka **Pengaturan HP → Sistem → Bahasa & Masukan → Keyboard di layar → Kelola keyboard**, lalu aktifkan **Simple Keyboard**.
